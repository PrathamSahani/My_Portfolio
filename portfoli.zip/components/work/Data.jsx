
import Work1 from "../../assets/web1.png"
import Work2 from "../../assets/web2.png"
import Work3 from "../../assets/app1.png"
import Work4 from "../../assets/app2.png"
import Work5 from "../../assets/Python1.png"


export const projectsData = [
    {
        id: 1,
        image: Work1,
        title: (
            <a
            href="https://lucent-conkies-304b95.netlify.app/"
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: "black" }} // Add your desired color here
          >
            Web Design
          </a>
          ),
        category: "web",
    },
    {
        id: 2,
        image: Work2,
        title: (
            <a
            href="https://prathamsahani.github.io/HEALTH-WEBSITE/"
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: "black" }} // Add your desired color here
          >
            Web Design
          </a>
          ),
        category: "web",
    },
    {
        id: 3,
        image: Work3,
        title: (
            <a
            href="https://spontaneous-biscuit-0f4fab.netlify.app/"
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: "black" }} // Add your desired color here
          >
            App movil
          </a>
          ),
        category: "app",
    },
    {
        id: 4,
        image: Work4,
        title: (
            <a
            href="https://github.com/PrathamSahani/React-Calculator"
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: "black" }} // Add your desired color here
          >
            App movil
          </a>
          ),
        category: "app",
    },
    {
        id: 5,
        image: Work5,
        title: (
            <a
            href="https://www.geeksforgeeks.org/machine-learning-diabetes-prediction-project-in-django/"
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: "black" }} // Add your desired color here
          >
            Published Project Link
          </a>
          ),
        category: "Design",
    },
];


export const projectsNav =[
    {
        name: 'all',
    },
    {
        name: 'web',
    },
    {
        name: 'app',
    },
    {
        name: 'design',
    },
];





