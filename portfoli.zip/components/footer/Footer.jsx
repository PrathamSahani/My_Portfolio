import React from 'react'
import "./footer.css";

const Footer = () => {
    return (
        <footer className='footer'>
            <div className='footer__container container'>

                <ul className='footer__list'>
                    <li>
                        <a href="#about" className='footer__link'>About</a>
                    </li>

                    <li>
                        <a href="#portfolio" className='footer__link'>Projects</a>
                    </li>
                    <li>
                        <a href="#testimonials" className='footer__link'>Testimonials</a>
                    </li>

                </ul>
                <div className="footer__social">
                    <a href="https://www.linkedin.com/in/pratham-sahani-3a0791239/
" className='footer__social-link' target='_blank'>
                        <i class="uil uil-linkedin-alt"></i>
                    </a>

                    <a href="https://linktr.ee/prathamsahani0368
" className='footer__social-link' target='_blank'>
                        <i class="uil uil-dribbble"></i>
                    </a>
                    <a href="https://github.com/PrathamSahani
" className='footer__social-link' target='_blank'>
                        <i class="uil uil-github-alt"></i>
                    </a>
                </div>
                <span className='footer__copy'>&#169; Pratham_Sahani. All rigths reserved</span>

            </div>
        </footer>
    )
}

export default Footer