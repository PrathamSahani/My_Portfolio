import React, { useState } from 'react'
import "./services.css";


const Services = () => {
    const [toggleState, setToggleState] =useState(0);

    const toggleTab = (index) => {
    setToggleState(index);
}
  return (
    
    <section className="services section" id="services">
    <h2 className="section__title">Services </h2>
    <span className="section__subtitle">What i offer
    </span>
    <div className ="services__container container grid">
    <div className="services__content">
            <div>
                <i  className="uil uil-web-grid services__icon"></i>
                <h3 className="services__title">Web <br/> Designer   </h3>
            </div>
            <span className="services__button" onClick={() => toggleTab(1)}>View More <i className="uil uil-arrow-right services__button-icon"></i></span>

            <div className={toggleState === 1?  "services__modal active-modal" : "services__modal"}>
                <div className="services__modal-content">
                    <i onClick={() => toggleTab(0)} className="uil uil-times services__modal-close"></i>

                    <h3 className="services__modal-title">Web Developer
                    </h3>
                    <p className="services__modal-description">Service with more than 1+ years of experience.Providing quality work to clients and companies.</p>
                    <ul className="services__modal-services grid">
                        <li className="services__modal-service">
                            <i className="uil uil-check-circle services__modal-icon"></i>
                            <p className="services__modal-info">I created fully responsive website  </p>
                        </li>

                        <li className="services__modal-service">
                            <i className="uil uil-check-circle services__modal-icon"></i>
                            <p className="services__modal-info">I used mainly HTML, CSS, and javascript</p>
                        </li>
                        <li className="services__modal-service">
                            <i className="uil uil-check-circle services__modal-icon"></i>
                            <p className="services__modal-info"> I published 3 to 4 article on GFG related to web developement.
                            </p>
                        </li>
                        <li className="services__modal-service">
                            <i className="uil uil-check-circle services__modal-icon"></i>
                            <p className="services__modal-info">I position your company brand.</p>
                        </li>
                        <li className="services__modal-service">
                            <i className="uil uil-check-circle services__modal-icon"></i>
                            <p className="services__modal-info">Design and mockups of products for companies.
                                .</p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div className="services__content">
            <div>
                <i className="uil uil-arrow services__icon"></i>
                <h3 className="services__title"> Java  <br/> Developer
                </h3>
            </div>
            <span onClick={() => toggleTab(2)} className="services__button">View More <i className="uil uil-arrow-right services__button-icon"></i></span>

            <div className={toggleState === 2?  "services__modal active-modal" : "services__modal"}>
                <div className="services__modal-content">
                    <i   onClick={() => toggleTab(0)} className="uil uil-times services__modal-close"></i>

                    <h3 className="services__modal-title"> Proficient in Java
                    </h3>
                    <p className="services__modal-description">Service with more than 1+ years of experience.Providing quality work to clients and companies.</p>
                    <ul className="services__modal-services grid">
                        <li className="services__modal-service">
                            <i className="uil uil-check-circle services__modal-icon"></i>
                            <p className="services__modal-info">Doing Programming in Java .</p>
                        </li>

                        <li className="services__modal-service">
                            <i className="uil uil-check-circle services__modal-icon"></i>
                            <p className="services__modal-info">5th rank in GeeksforGeeks Institute rank</p>
                        </li>
                        <li className="services__modal-service">
                            <i className="uil uil-check-circle services__modal-icon"></i>
                            <p className="services__modal-info">3+ Star on Leetcode.
                            </p>
                        </li>
                        <li className="services__modal-service">
                            <i className="uil uil-check-circle services__modal-icon"></i>
                            <p className="services__modal-info">Participate more than 25+ on Leetcode</p>
                        </li>
                        <li className="services__modal-service">
                            <i className="uil uil-check-circle services__modal-icon"></i>
                            <p className="services__modal-info">Used Multiple Platform for doing Programmin in Java Leetcode, Codechef, Coding Ninja and also Codechef.
                                .</p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
      

        <div className="services__content">
            <div>
                <i className="uil uil-edit services__icon"></i>
                <h3 className="services__title"> Technical Content <br/> Writer
                </h3>
            </div>
            <span onClick={()=> toggleTab(3)}  className="services__button">View More <i className="uil uil-arrow-right services__button-icon"></i></span>

            <div className={toggleState === 3?  "services__modal active-modal" : "services__modal"}>
                <div className="services__modal-content">
                    <i  onClick={() => toggleTab(0)} className="uil uil-times services__modal-close"></i>

                    <h3 className="services__modal-title">Content Writer
                    </h3>
                    <p className="services__modal-description">Service with more than 1+ years of experience.Providing quality work to clients and companies.</p>
                    <ul className="services__modal-services grid">
                        <li className="services__modal-service">
                            <i className="uil uil-check-circle services__modal-icon"></i>
                            <p className="services__modal-info">Write Technical content in Proficient.</p>
                        </li>

                        <li className="services__modal-service">
                            <i className="uil uil-check-circle services__modal-icon"></i>
                            <p className="services__modal-info">Published more than 10 + article on GeeksforGeeks.</p>
                        </li>
                        <li className="services__modal-service">
                            <i className="uil uil-check-circle services__modal-icon"></i>
                            <p className="services__modal-info">Three Pyhton (Django) ML Project publsihed on GeeksfoGeeks.
                            </p>
                        </li>
                        <li className="services__modal-service">
                            <i className="uil uil-check-circle services__modal-icon"></i>
                            <p className="services__modal-info">I completed three month internship at GeeksforGeeks</p>
                        </li>
                        <li className="services__modal-service">
                            <i className="uil uil-check-circle services__modal-icon"></i>
                            <p className="services__modal-info">I awarded by GeeksforGeeks after publishing 10 Technical article successfully.
                                .</p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
  )
}

export default Services